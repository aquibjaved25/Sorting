package com.example.aquib.sortingandroid;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by Aquib on 4/17/2017.
 *
 */

class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ViewHolder> {

    private Context context;
    private ArrayList<Bean> nameList;

    class ViewHolder extends RecyclerView.ViewHolder {
        private TextView textView;
        private TextView textView1;
        private ImageView image;

        ViewHolder(View itemView) {
            super(itemView);

            textView = (TextView) itemView.findViewById(R.id.tv_data);
            textView1 = (TextView) itemView.findViewById(R.id.tv_secondary_data);
            image = (ImageView) itemView.findViewById(R.id.row_image);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(context, "On Click" + (getAdapterPosition() + 1), Toast.LENGTH_SHORT).show();
                    image.setImageResource(R.mipmap.ic_launcher);
                }
            });

            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    image.setImageResource(R.mipmap.ic_launcher_round);
                    Toast.makeText(context, "OnLongClick" + (getAdapterPosition() + 1), Toast.LENGTH_SHORT).show();
                    return false;
                }
            });
        }

        private TextView getTextView() {
            return textView;
        }

        private TextView getTextView1() {
            return textView1;
        }

        private ImageView getImageView() {
            return image;
        }
    }

    RecyclerAdapter(Context context, ArrayList<Bean> nameList)

    {
        this.context = context;
        this.nameList = nameList;
    }

    @Override
    public RecyclerAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {


        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_item, parent, false);

        return new ViewHolder(v);

    }

    @Override
    public void onBindViewHolder(RecyclerAdapter.ViewHolder holder, int position) {
        holder.getTextView().setText(nameList.get(position).getBoysName());
        holder.getTextView1().setText(nameList.get(position).getGirlsName());
        holder.getImageView().setImageResource(R.mipmap.ic_launcher_round);
    }

    @Override
    public int getItemCount() {
        return nameList.size();
    }
}
