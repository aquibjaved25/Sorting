package com.example.aquib.sortingandroid;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Bean> nameList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       /* ArrayList<String> names = new ArrayList<String>();
        names.add("seetha");
        names.add("sudhin");
        names.add("Swetha");
        names.add("Neethu");
        names.add("ananya");
        names.add("Athira");
        names.add("bala");
        names.add("Tony");
        names.add("Karthika");
        names.add("Nithin");
        names.add("Vinod");
        names.add("jeena");
        names.add("zoya");
        //Collections.sort(names);

        Collections.sort(names, new Comparator<String>() {
            @Override
            public int compare(String lhs, String rhs) {
                return lhs.compareToIgnoreCase(rhs);
            }
        });
        for(int i=0; i<names.size(); i++)
            System.out.println(names.get(i));*/
        getdata();
        getId();
    }

    private void getdata() {

        Bean bean1 = new Bean("Rahul", "Riya");
        Bean bean2 = new Bean("Ramesh", "Sushmita");
        Bean bean3 = new Bean("Suresh", "Aishwarya");
        Bean bean4 = new Bean("Dinesh", "Rupa");
        Bean bean5 = new Bean("Ravi", "Deepika");
        Bean bean6 = new Bean("Vikky", "Kritika");
        Bean bean7 = new Bean("Vikram", "Diya");
        Bean bean8 = new Bean("Kartik", "Radhika");
        nameList.add(bean1);
        nameList.add(bean2);
        nameList.add(bean3);
        nameList.add(bean4);
        nameList.add(bean5);
        nameList.add(bean6);
        nameList.add(bean7);
        nameList.add(bean8);

        Collections.sort(nameList, new Comparator<Bean>() {
            @Override
            public int compare(Bean lhs, Bean rhs) {
                //return lhs.getBoysName().compareTo(rhs.getBoysName()); //This will Sort First all Caps then all Small;like A,L,a,k
                //return lhs.getBoysName().compareToIgnoreCase(rhs.getBoysName()); // THis will Sort:-A,a,K,L
                return rhs.getBoysName().compareToIgnoreCase(lhs.getBoysName()); //This is Reverse
            }
        });

    }

    private void getId() {
        RecyclerView mRecyclerView = (RecyclerView) findViewById(R.id.recycler);
        RecyclerView.LayoutManager LayoutManager = new LinearLayoutManager(MainActivity.this);

        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(LayoutManager);

        RecyclerAdapter adapter = new RecyclerAdapter(MainActivity.this, nameList);
        mRecyclerView.setAdapter(adapter);

    }
}
